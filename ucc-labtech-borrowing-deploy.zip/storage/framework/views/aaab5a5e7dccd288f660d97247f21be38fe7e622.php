<div
    class="mb-3 mt-8 px-3 text-xs font-semibold uppercase
           tracking-wider text-green-300"
>
    Administration
</div>

<div class="space-y-1">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view users')): ?>
        <a
            href="<?php echo e(route('users.index')); ?>"
            class="flex items-center gap-3 rounded-xl px-4 py-3
                   text-sm font-medium transition
                   <?php echo e(request()->routeIs('users.*')
                        ? 'bg-white text-green-800 shadow-sm'
                        : 'text-green-100 hover:bg-green-700'); ?>"
        >
            <img
                src="<?php echo e(asset('images/icons/users_icon.png')); ?>"
                alt=""
                aria-hidden="true"
                class="h-5 w-5 shrink-0 object-contain"
            >

            Users
        </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view maintenance')): ?>
        <a
            href="<?php echo e(route('maintenance.index')); ?>"
            class="flex items-center gap-3 rounded-xl px-4 py-3
                   text-sm font-medium transition
                   <?php echo e(request()->routeIs('maintenance.*')
                        ? 'bg-white text-green-800 shadow-sm'
                        : 'text-green-100 hover:bg-green-700'); ?>"
        >
            <img
                src="<?php echo e(asset('images/icons/maintenance_logo.png')); ?>"
                alt=""
                aria-hidden="true"
                class="h-5 w-5 shrink-0 object-contain"
            >

            Maintenance
        </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view reports')): ?>
        <a
            href="<?php echo e(route('reports.index')); ?>"
            class="flex items-center gap-3 rounded-xl px-4 py-3
                   text-sm font-medium transition
                   <?php echo e(request()->routeIs('reports.*')
                        ? 'bg-white text-green-800 shadow-sm'
                        : 'text-green-100 hover:bg-green-700'); ?>"
        >
            <img
                src="<?php echo e(asset('images/icons/reports_icon.png')); ?>"
                alt=""
                aria-hidden="true"
                class="h-5 w-5 shrink-0 object-contain"
            >

            Reports
        </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view activity logs')): ?>
        <a
            href="<?php echo e(route('audit-logs.index')); ?>"
            class="flex items-center gap-3 rounded-xl px-4 py-3
                   text-sm font-medium transition
                   <?php echo e(request()->routeIs('audit-logs.*')
                        ? 'bg-white text-green-800 shadow-sm'
                        : 'text-green-100 hover:bg-green-700'); ?>"
        >
            <img
                src="<?php echo e(asset('images/icons/audit_logo.png')); ?>"
                alt=""
                aria-hidden="true"
                class="h-5 w-5 shrink-0 object-contain"
            >

            Audit Logs
        </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage settings')): ?>
        <a
            href="<?php echo e(route('settings.index')); ?>"
            class="flex items-center gap-3 rounded-xl px-4 py-3
                   text-sm font-medium transition
                   <?php echo e(request()->routeIs('settings.*')
                        ? 'bg-white text-green-800 shadow-sm'
                        : 'text-green-100 hover:bg-green-700'); ?>"
        >
            <img
                src="<?php echo e(asset('images/icons/settings_icon.png')); ?>"
                alt=""
                aria-hidden="true"
                class="h-5 w-5 shrink-0 object-contain"
            >

            Settings
        </a>
    <?php endif; ?>
</div><?php /**PATH C:\Users\James Ryan Gregorio\ucc-labtech-borrowing\resources\views/layouts/partials/administration-links.blade.php ENDPATH**/ ?>
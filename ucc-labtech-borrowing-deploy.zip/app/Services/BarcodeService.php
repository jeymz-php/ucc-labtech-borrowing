<?php

namespace App\Services;

use InvalidArgumentException;

class BarcodeService
{
    private const PATTERNS = [
        '0'=>'101001101101','1'=>'110100101011','2'=>'101100101011','3'=>'110110010101','4'=>'101001101011','5'=>'110100110101','6'=>'101100110101','7'=>'101001011011','8'=>'110100101101','9'=>'101100101101',
        'A'=>'110101001011','B'=>'101101001011','C'=>'110110100101','D'=>'101011001011','E'=>'110101100101','F'=>'101101100101','G'=>'101010011011','H'=>'110101001101','I'=>'101101001101','J'=>'101011001101',
        'K'=>'110101010011','L'=>'101101010011','M'=>'110110101001','N'=>'101011010011','O'=>'110101101001','P'=>'101101101001','Q'=>'101010110011','R'=>'110101011001','S'=>'101101011001','T'=>'101011011001',
        'U'=>'110010101011','V'=>'100110101011','W'=>'110011010101','X'=>'100101101011','Y'=>'110010110101','Z'=>'100110110101','-'=>'100101011011','.'=>'110010101101',' '=>'100110101101','$'=>'100100100101','/'=>'100100101001','+'=>'100101001001','%'=>'101001001001','*'=>'100101101101',
    ];

    public function svg(string $value, int $height = 70, int $moduleWidth = 2): string
    {
        $value = strtoupper(trim($value));

        if ($value === '' || preg_match('/[^0-9A-Z. \-\$\/+%]/', $value)) {
            throw new InvalidArgumentException('Unsupported Code 39 barcode value.');
        }

        $encoded = '*' . $value . '*';
        $quiet = 10;
        $x = $quiet;
        $bars = [];

        foreach (str_split($encoded) as $character) {
            $pattern = self::PATTERNS[$character];
            foreach (str_split($pattern) as $index => $bit) {
                if ($bit === '1') {
                    $bars[] = sprintf('<rect x="%d" y="0" width="%d" height="%d"/>', $x, $moduleWidth, $height);
                }
                $x += $moduleWidth;
            }
            $x += $moduleWidth;
        }

        $width = $x + $quiet;
        $safeValue = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');

        return sprintf(
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %1$d %2$d" role="img" aria-label="Barcode %3$s"><rect width="100%%" height="100%%" fill="white"/><g fill="black">%4$s</g></svg>',
            $width,
            $height,
            $safeValue,
            implode('', $bars)
        );
    }
}
